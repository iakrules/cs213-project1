/**
 * Driver class used to run Project 1.
 *
 * @author Ishaan Keswani, Akhil Thalasila
 */
public class RunProject1 {
    public static void main(String[] args) {
        new RosterManager().run();
    }
}